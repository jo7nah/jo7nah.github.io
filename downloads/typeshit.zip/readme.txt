thank you for downloading my font!

feel free to use the font for any personal or academic projects. for commercial use, please contact me via email

jonah.alisic@icloud.com

and explain the specific use case.

<3